In this dir the most recent versions of the input gdx files should be copied.
The following names should used:
- params.gdx  : for the scaled data
- params_nsc.gdx  : for the original (not scaled) data

The files dated Dec 27 were used for the tests JZ made on that date, and MM
made on Jan 21, 2022

