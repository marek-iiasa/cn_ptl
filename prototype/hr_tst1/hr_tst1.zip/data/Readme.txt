The content of *gdx files:
- demand.gdx : actual demand
- demand0.gdx : all demands set to 0 (used for testing)
