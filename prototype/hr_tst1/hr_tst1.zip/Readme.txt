This dir contains the complete set of gams files of the CN_PTL model
generated in the message_ix framework, prepared for single-criterion
optimization (minimizes OBJ, i.e. the total cost).

The gams cmd-lines are defined in the run file (the commented file
run with the input parameter file demand0.gdx which sets all demands
to zero).
